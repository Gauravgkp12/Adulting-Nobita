const express = require('express');
const Log = express.Router();

Log.get('/',(err,res) => {
    res.send("ggg")
})

module.exports = Log;