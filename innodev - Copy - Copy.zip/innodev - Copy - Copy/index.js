const express  = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Home = require('./loginjs/Home')

const port = process.env.port || 5050;
const app = express();
app.set('view engine','ejs')
app.use(bodyParser.urlencoded({ extended: false }))


app.use(bodyParser.json())

app.use('/',Home)
app.listen(port)