const express = require("express")
const mongoose = require("mongoose");
const app = express();
const url = "mongodb+srv://naman_singh:NAMAN123SINGH@hope.29dwjgb.mongodb.net/?retryWrites=true&w=majority"
async function connect() {
    try {
        await mongoose.connect(url)
        console.log("connected to MongoDB")
    } catch(error)
    {
        console.error(error);
    }
}

connect();

app.listen(8000,() => {
    console.log("server started on port 8000");
})



// -------------------------------------------------------video chat----------------------------------------------------//
//const express = require("express")
const server = require('http').Server(app)
const io = require('socket.io')(server) //npm i --save-dev @types/socket.io
const { ExpressPeerServer } = require('peer');
const peerServer = ExpressPeerServer(server, {
  debug: true
});
const { v4: uuidV4 } = require('uuid')

app.use('/peerjs', peerServer);

app.set('view engine', 'ejs')
app.use(express.static('public'))

app.get('/', (req, res) => {
  res.redirect(`/${uuidV4()}`)
})

app.get('/:room', (req, res) => {
  res.render('room', { roomId: req.params.room })
})

io.on('connection', socket => {
  socket.on('join-room', (roomId, userId) => {
    socket.join(roomId)
    socket.to(roomId).broadcast.emit('user-connected', userId);
    // messages
    socket.on('message', (message) => {
      //send message to the same room
      io.to(roomId).emit('createMessage', message)
  }); 

    socket.on('disconnect', () => {
      socket.to(roomId).broadcast.emit('user-disconnected', userId)
    })
  })
})

server.listen(process.env.PORT||3030)